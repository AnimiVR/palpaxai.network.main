Icon files generated!

For best compatibility, convert SVG to PNG:
- icon16.svg -> icon16.png (16x16)
- icon32.svg -> icon32.png (32x32)
- icon48.svg -> icon48.png (48x48)
- icon128.svg -> icon128.png (128x128)

You can use online converters like:
- https://cloudconvert.com/svg-to-png
- Or any image editor
